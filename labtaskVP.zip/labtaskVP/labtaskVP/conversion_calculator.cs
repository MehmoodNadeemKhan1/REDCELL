﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labtaskVP
{
    public partial class conversion_calculator : Form
    {
        public conversion_calculator()
        {
            InitializeComponent();
        }
    }
}
